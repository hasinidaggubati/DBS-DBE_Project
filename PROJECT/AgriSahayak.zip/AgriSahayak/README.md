# AgriSahayak

Agriculture & AgriTech Mobile App for Farmer Self-Service.

This package is deliberately separated into two folders:

```text
AgriSahayak/
├── backend/     <- Spring Boot REST API + farmer/crop persistence
└── frontend/    <- HTML + CSS + JavaScript UI
```

## Start the project

### 1. Backend
Open a terminal in `backend`:

```powershell
mvn org.springframework.boot:spring-boot-maven-plugin:3.5.5:run
```

### 2. Frontend
Open `frontend` in VS Code and run `index.html` with Live Server.

The frontend connects to:

`http://localhost:8080`

## Online / Offline flow

- Online: register/login, use live weather, get backend crop recommendations, and save records to the farmer account.
- Offline: continue offline, enter field data, get the browser fallback crop recommendation, and save records locally.
- When internet returns: login/register and pending offline crop records are automatically queued for synchronization to the backend.
- Previous crop data is shown in the saved crop history.
